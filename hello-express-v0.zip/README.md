# Hello-Express

A simple Express app to test continuous deployment in Amazon Elastic Beanstalk

## Installation

Using Node/NPM

```bash
npm install
npm run start
```
